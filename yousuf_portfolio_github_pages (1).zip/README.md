# Muhammad Yousuf — Portfolio Website

## Files
- `index.html` — responsive portfolio website
- `profile.png` — your supplied portrait

## Publish on GitHub Pages
1. Create a GitHub repository named `YOUR-USERNAME.github.io` (replace with your GitHub username).
2. Upload both `index.html` and `profile.png` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, then Save.
5. Wait for GitHub Pages to publish your website.

## Before publishing
- Confirm that the project URLs are yours and live; replace or remove any that are not your work.
- Replace the generic Fiverr profile link with your actual Fiverr profile URL.
- Verify the WhatsApp number and email address in the contact section.
- Add real screenshots and project-specific descriptions for the strongest portfolio.
